#calificacion de la comida
paga = 2500
comision = 0.3
calif = int(input("del 1 al 5 califique su comida\n"))
if calif > 4:
    input("agregue un comentario\n")
    input("puntos a destacar de su comida?\n")
else:
    input("que falló?\n")
#calificacion a la persona que atendio
calif2 = int(input("Del 1 al 5 que tal estuvo el servicio al cliente?\n"))
if calif2 > 4:
    input("agregue un comentario\n")
    input("puntos a destacar?\n")
    califper = int(input("Del 1 al 7 como fue atendido?\n"))
    if califper > 6:
        pagatot1 = comision + paga
else:
    input("que fallo?")
    pagatot2 = comision - paga
    print("se le sumara comision\n")
#calificacion al restaurante
calif3 = int(input("Del 1 al 5 califique al restaurante\n"))
if calif3 > 4:
    input("agregue un comentario")
    input("puntos a destacar?")
else:
    input("que estuvo mal?")
#calificaciones
print("su calificacion de comida fue ",calif," de 5\n")
print("su calificacion de servicio al cliente fue de ",calif2," de 5\n")
print("su calificacion de personal fue de ",califper," de 7\n")
print("su calificacion de restaurante fue de ",calif3," de 5\n")